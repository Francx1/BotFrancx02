## <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Hi.gif" width="29px"> FEITO E TRADUZIDO POR: DARK YT
<p align="center">
<img src="https://media-giphy-com.cdn.ampproject.org/ii/w820/s/media.giphy.com/media/1g3A0gpaidxWcL9Mfo/giphy.gif" width="230" height="230"/>
</p>
<br>


 
</details>

### ATENÇÃO
DESEJA RE-CARREGAR O SCRIPT? AMO MEU NOME / LINK CHANEL .... NÃO ALTERE A INFORMAÇÃO !!!

## NOTA:>
NÃO VENDE / COMPRE O SCRIPT, ESTE SCRIPT É 100% GRATUITO PARA OS USUÁRIOS DO TERMUX
</div>

### FERRAMENTAS E MATERIAIS <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Hello_Big.gif" width="29px">
Prepare as ferramentas e materiais.
`` `bash
> 2 telefones celulares (1 para executar SC, 1 para ler o código QR sis)
> rede de internet rápida, cota +
> armazenamento adequado
> aplicativo whatsapp
> aplicativo termux
> café + cigarros KKKK;-;
```
INSTALAÇÃO:

> Se você não tiver o APK Termux, baixe-o na Playstore
> entre no apk termux e digite abaixo!
> termux-setup-storage
> pkg install git && pkg install tesseract && pkg install wget && pkg install ffmpeg && pkg install nodejs
> apt update && apt upgrade
> git clone https://github.com/Darkziinh/Dark
> cd dark
> npm i -g cwebp && npm i node-tesseract-ocr && npm i -g ytdl && npm i  && npm i got && node index js
> Basta escanear o código qr e ... pronto
```

## CARACTERÍSTICAS  <img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Earth.gif" width="29px">

| D4RK BOT      |                   Característica        |
| :-----------: | :------------------------------: |
|       ✅       | Criador de adesivos                  |
|       ✅       | Nulis                            |
|       ✅       | Covid (Novo)                      |
|       ✅       | Alay (novo)                       |
|       ✅       | Letras (novo)                      |
|       ✅       | Foto Anime                       |
|       ✅       | Fotos de menina / menino (Novo)           |
|       ✅       | Pantun                           |
|       ✅       | Youtube Downloader               |
|       ✅       | Quotes                           |
|       ✅       | Nome (Novo)                       |
|       ✅       | Foto Anime                       |
|       ✅       | Casal (Novo)                   |
|       ✅       | Oração (Novo )                    |
|       ✅       | Google Voice (fix)               |
|       ✅       | Alcorão                            |
|       ✅       | Downloader MP3 do Youtube           |
|       ✅       | Downloader Instagram              |
|       ✅       | Twitter Downloader               |
|       ✅       | Downloader do Facebook              |
|       ✅       | Downloader TikTok (novo)         |
|       ✅       | Wikipedia                        |
|       ✅       | Say                              |
|       ✅       | Tóxico (Novo)                      |
|       ✅       | loli                             |
|       ✅       | hentai                           |
|       ✅       | Proprietário (novo)                      |
|       ✅       | disse o sábio                       |
|       ✅       | Facto                            |
|       ✅       | Pokemon                          |
|       ✅       | Info                             |
|       ✅       | Doar                           |
|       ✅       | 18+.                             |
|       ✅       | MAIS recursos em breve 🍂        |

DARKZIN DOMINA 🐦❤️

<img src="https://github.com/TheDudeThatCode/TheDudeThatCode/blob/master/Assets/Mario_Gameplay.gif" alt="Mario Game" width="600" />

